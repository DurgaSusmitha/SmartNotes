package com.example.smartnotess;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity
{
    FirebaseAuth mAuth;
    RelativeLayout relativeLayout;
    EditText id,passd;
    Button login;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mAuth = FirebaseAuth.getInstance();
        setContentView(R.layout.activity_main);
        TextView bt1=findViewById(R.id.signin);
        id=findViewById(R.id.userid);
        passd=findViewById(R.id.passd);
        login = findViewById(R.id.buttonsub);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                signin();
            }
        });

        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,RegisterActivity.class));
            }
        });
    }
    private  void signin(){
        String email = id.getText().toString();
        String password = passd.getText().toString();
        if(TextUtils.isEmpty(email)){
            id.setError("Email cannot be empty");
            id.requestFocus();
        }
        else if(TextUtils.isEmpty(password)){
            passd.setError("Password cannot be Empty");
            passd.requestFocus();
        }
        else {
            mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if(task.isSuccessful()){
                        login.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                startActivity(new Intent(MainActivity.this,SecondActivity.class));

                            }
                        });
                    }
                    else
                    {
                        Toast.makeText(MainActivity.this,"login failed",Toast.LENGTH_SHORT).show();
                    }
                }
            });
        }

    }

}