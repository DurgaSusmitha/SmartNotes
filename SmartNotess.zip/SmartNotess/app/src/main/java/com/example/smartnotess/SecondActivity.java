package com.example.smartnotess;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toolbar;


import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class SecondActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawablelayout;
    NavigationView navigationView;
    Toolbar toolbar;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        androidx.appcompat.widget.Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        drawablelayout = findViewById(R.id.my_drawer_layout);
        NavigationView nv = findViewById(R.id.nav_view);
        nv.setNavigationItemSelectedListener(this);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawablelayout,toolbar,R.string.nav_open,R.string.nav_close);
        drawablelayout.addDrawerListener(toggle);
        toggle.syncState();

        if (savedInstanceState == null)
        {
            getSupportFragmentManager().beginTransaction().replace(R.id.frag_cont,new AddFragment()).commit();
            nv.setCheckedItem(R.id.setting);
        }

    }

    @Override
    public void onBackPressed() {
        if(drawablelayout.isDrawerOpen(GravityCompat.START)){
            drawablelayout.closeDrawer(GravityCompat.START);
        }
        else{
            super.onBackPressed();
        }
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item)
    {
        switch (item.getItemId())
        {
            case R.id.logt:
                AlertDialog.Builder builder=new AlertDialog.Builder(SecondActivity.this);

                builder.setTitle("Logout")

                        .setMessage("Are you sure?")

                        .setCancelable(false)

                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {

                            @Override

                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent ii=new Intent(getApplicationContext(),MainActivity.class);
                                startActivity(ii);
                            }

                        })

                        .setNegativeButton("No", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                Intent ii=new Intent(getApplicationContext(),SecondActivity.class);
                                startActivity(ii);
                            }
                        });
                AlertDialog dialog= builder.create();
                dialog.show();
                break;
            case R.id.setting:
                getSupportFragmentManager().beginTransaction().replace(R.id.frag_cont, new SettingsFragment()).commit();
            break;
        }
        drawablelayout.closeDrawer(GravityCompat.START);
        return true;
    }
}
